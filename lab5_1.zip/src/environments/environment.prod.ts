export const environment = {
  firebase: {
    // add your Firebase config here
  },
  production: true
};
